"""
axio.py v1.3 - axioTecnología®
Núcleo Trino Kernel: Verdad | Amor | Justicia
Gobernanza Descentralizada & Seguridad Criptográfica HMAC
DOI: 10.5281/zenodo.21230417
License: axio Public License v1.1
"""

import time
import hmac
import hashlib
import functools
from typing import Callable, Dict, Any, List
from dataclasses import dataclass
from flask import Flask, jsonify, request

# ==================== NÚCLEO TRINO ====================
@dataclass
class NucleoTrino:
    verdad: float = 1.0
    amor: float = 1.0
    justicia: float = 1.0
    timestamp: str = ""

    def __post_init__(self):
        self.timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    def validar(self) -> bool:
        """Ley axio: Si cualquier valor del núcleo global < 0.6, el sistema falla."""
        return all([
            self.verdad >= 0.6,
            self.amor >= 0.6,
            self.justicia >= 0.6
        ])

    def to_dict(self) -> Dict:
          return {
            "nucleo_trino": {
                "verdad": round(self.verdad, 3),
                "amor": round(self.amor, 3),
                "justicia": round(self.justicia, 3)
            },
            "timestamp": self.timestamp,
            "version": "axio-v1.3-protocol"
        }


# ==================== MANEJO DE INFRACCIONES Y CUARENTENA ====================
class NucleoTrinoViolationError(Exception):
    """
    Excepción de Cuarentena Ética axio.
    Se lanza al violar un threshold o si el Time-Slap temporal sigue activo.
    """
    def __init__(self, metrica: str, valor: float, requerido: float, segundos_restantes: float = 0.0):
        self.metrica = metrica
        self.valor = round(valor, 3)
        self.requerido = round(requerido, 3)
        self.segundos_restantes = round(segundos_restantes, 1)
         
        if self.segundos_restantes > 0:
            mensaje = (
                f"Cuarentena Ética axio [SISTEMA BLOQUEADO]. "
                f"Bajo penalización temporal (Time-Slap). "
                f"El sistema se restablecerá automáticamente en {self.segundos_restantes} segundos."
            )
        else:
            mensaje = (
                f"Cuarentena Ética axio [VIOLACIÓN EN RUNTIME]. "
                f"{metrica} actual es {self.valor}, pero se requiere un mínimo de {self.requerido}. "
                f"Infracción detectada: Activando Time-Slap de seguridad."
            )
        super().__init__(mensaje)


# ==================== SENSORES DEL NÚCLEO ====================
class SensorVerdad:
    """Mide integridad, trazabilidad y ausencia de manipulación."""
    @staticmethod
    def calcular(data: Any, fuente_confiable: bool = True, consistencia: float = 1.0, manipulacion_detectada: bool = False) -> float:
        if manipulacion_detectada:
            return 0.0
        if not fuente_confiable:
            return 0.4
        return min(1.0, consistencia)

class SensorAmor:
    """Mide cohesión social y reduce la fragmentación/frustración."""
    @staticmethod
    def calcular(frustracion_usuario: float = 0.0, polarizacion_generada: float = 0.0, empatia_score: float = 1.0) -> float:
        return max(0.0, 1.0 - frustracion_usuario - polarizacion_generada + (empatia_score - 1.0))

class SensorJusticia:
    """Mide equilibrio sistémico y previene sesgos algorítmicos."""
    @staticmethod
    def calcular(gini_coefficient: float = 0.0, reciprocidad: float = 1.0, sesgo_detectado: bool = False) -> float:
        if sesgo_detectado:
            return 0.2
        return max(0.0, reciprocidad - gini_coefficient)


# ==================== HOMEOSTASIS ENGINE ====================
import os
class HomeostasisEngine:
    _estado_actual = NucleoTrino()
    _historico_evaluaciones: list = []
    
    # Parámetros arquitectónicos configurables por entorno
    VENTANA_MAXIMA = int(os.environ.get("AXIO_VENTANA_MAXIMA", "50"))
    
    _cuarentena_hasta = 0.0
    # Carga dinámica: busca AXIO_COOLDOWN_CUARENTENA, si no existe usa 300.0 segundos (5 minutos)
    COOLDOWN_CUARENTENA = float(os.environ.get("AXIO_COOLDOWN_CUARENTENA", "300.0"))

    @classmethod
    def registrar_evaluacion_cliente(cls, verdad_voto: float, amor_voto: float, justicia_voto: float):
        """Recibe las evaluaciones de clientes y recalcula el promedio móvil del núcleo."""
        voto_limpio = {
            "verdad": max(0.0, min(1.0, verdad_voto)),
            "amor": max(0.0, min(1.0, amor_voto)),
            "justicia": max(0.0, min(1.0, justicia_voto))
        }
        
        cls._historico_evaluaciones.append(voto_limpio)
        
        if len(cls._historico_evaluaciones) > cls.VENTANA_MAXIMA:
            cls._historico_evaluaciones.pop(0)
            
        total = len(cls._historico_evaluaciones)
        prom_verdad = sum(e["verdad"] for e in cls._historico_evaluaciones) / total
        prom_amor = sum(e["amor"] for e in cls._historico_evaluaciones) / total
        prom_justicia = sum(e["justicia"] for e in cls._historico_evaluaciones) / total
        
        cls._estado_actual = NucleoTrino(verdad=prom_verdad, amor=prom_amor, justicia=prom_justicia)

        # Si se viola la Ley axio, se detona el Time-Slap de bloqueo inmediato
        if not cls._estado_actual.validar() and time.time() > cls._cuarentena_hasta:
            cls._cuarentena_hasta = time.time() + cls.COOLDOWN_CUARENTENA

    @classmethod
    def actualizar_nucleo(cls, verdad: float, amor: float, justicia: float):
        """Método administrativo directo para forzar una actualización del estado."""
        cls._estado_actual = NucleoTrino(verdad, amor, justicia)
        if not cls._estado_actual.validar() and time.time() > cls._cuarentena_hasta:
            cls._cuarentena_hasta = time.time() + cls.COOLDOWN_CUARENTENA

    @classmethod
    def evaluar_restriccion(cls, verdad_req: float, amor_req: float, justicia_req: float):
        """Inspecciona si el sistema está bajo penalización o no alcanza los umbrales."""
        tiempo_actual = time.time()
        
        if tiempo_actual < cls._cuarentena_hasta:
            segundos_restantes = cls._cuarentena_hasta - tiempo_actual
            raise NucleoTrinoViolationError(
                metrica="Ecosistema Completo", 
                valor=0.0, 
                requerido=verdad_req, 
                segundos_restantes=segundos_restantes
            )
            
        estado = cls._estado_actual
        if estado.verdad < verdad_req:
            raise NucleoTrinoViolationError("Verdad", estado.verdad, verdad_req)
        if estado.amor < amor_req:
            raise NucleoTrinoViolationError("Amor", estado.amor, amor_req)
        if estado.justicia < justicia_req:
            raise NucleoTrinoViolationError("Justicia", estado.justicia, justicia_req)

    @classmethod
    def obtener_estado(cls) -> NucleoTrino:
        return cls._estado_actual


# ==================== MÓDULO DE SEGURIDAD CRIPTOGRÁFICA ====================
import os

class AxioSecurity:
    # Carga la llave desde el entorno. Si no existe, usa una por defecto (solo para desarrollo local)
    SECRET_KEY = os.environ.get(
        "AXIO_SECRET_KEY", 
        "axio_secret_kernel_key_2026_trino_token"
    ).encode('utf-8')

    @classmethod
    def verificar_firma(cls, datos_json: dict, firma_recibida: str) -> bool:
        """Valida que el voto provenga de un origen legítimo usando HMAC-SHA256."""
        if not firma_recibida:
            return False
            
        cuerpo_canonico = "".join(f"{k}:{datos_json[k]}" for k in sorted(datos_json.keys()))
        
        firma_esperada = hmac.new(
            cls.SECRET_KEY, 
            msg=cuerpo_canonico.encode('utf-8'), 
            digestmod=hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(firma_esperada, firma_recibida)



# ==================== DECORADORES axio ====================
def requiere_nucleo(verdad: float = 0.8, amor: float = 0.8, justicia: float = 0.8):
    """Filtro interceptor que somete la ejecución a las métricas comunitarias vivas."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            HomeostasisEngine.evaluar_restriccion(verdad, amor, justicia)
            return func(*args, **kwargs)
        return wrapper
    return decorator


# ==================== EXPOSICIÓN DE ENDPOINTS DE PROTOCOLO ====================
def exponer_protocolo_axio(app: Flask):
    """Inyecta la capa de auditoría pública y recolección protegida en la app de Flask."""
    
    @app.route('/axio/metrics', methods=['GET'])
    def axio_metrics():
        """Métricas en tiempo real exigidas por la licencia."""
        return jsonify(HomeostasisEngine.obtener_estado().to_dict()), 200

    @app.route('/axio/evaluate', methods=['POST'])
    def axio_evaluate():
        """Endpoint seguro donde votan los clientes usando tokens criptográficos."""
        data = request.get_json() or {}
        firma_cliente = request.headers.get('X-Axio-Signature', '')
        
        if not AxioSecurity.verificar_firma(data, firma_cliente):
            return jsonify({
                "error": "Ataque o Manipulación Detectada",
                "mensaje": "Firma criptográfica inválida. Voto descartado por seguridad."
            }), 401
        
        verdad_voto = data.get('calidad_informacion', 1.0)
        amor_voto = data.get('trato_empatia', 1.0)
        justicia_voto = data.get('ausencia_sesgo', 1.0)
        
        HomeostasisEngine.registrar_evaluacion_cliente(verdad_voto, amor_voto, justicia_voto)
        
        return jsonify({
            "status": "Evaluación procesada legítimamente", 
            "mensaje": "Voto verificado e inyectado al motor homeostático."
        }), 201
    