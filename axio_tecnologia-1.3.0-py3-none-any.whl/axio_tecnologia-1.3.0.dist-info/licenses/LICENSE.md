markdown
# axio Public License v1.1 (APL-1.1)

**Copyright (c) 2026 axioTecnología®**  
**Autor Principal:** Felipe de Jesús Zamora Vega  
**DOI de Referencia:** 10.5281/zenodo.21661763  
**Ubicación:** San Alfonso, Zempoala, Hidalgo, México  

---

## Preámbulo Ético-Legal

A diferencia de las licencias de software tradicionales orientadas exclusivamente a la propiedad intelectual o comercial, la **axio Public License (APL)** introduce el concepto de *Cumplimiento Homeostático Obligatorio*. Esta licencia asume que el software no es neutral y que su ejecución tiene un impacto directo en el tejido social, de datos y de justicia en el mundo. 

Por lo tanto, los derechos de uso, copia, modificación y distribución concedidos en este documento están **estrictamente condicionados** al mantenimiento de los tres valores fundamentales del Núcleo Trino: **Verdad**, **Amor** y **Justicia**.

---

## 1. Concesión de Licencia Condicional

Por la presente se concede a cualquier persona o entidad que obtenga una copia de este software y sus archivos de documentación asociados (el "Software"), el derecho de usar, copiar, modificar, fusionar, publicar y distribuir el Software, siempre y cuando cumpla ininterrumpidamente con las **Condiciones de Homeostasis Ética** descritas en la Sección 2.

---

## 2. Condiciones de Homeostasis Ética (La Ley axio)

El licenciatario acepta y se compromete a que la infraestructura tecnológica que ejecute este Software o cualquier derivado del mismo deberá operar bajo las siguientes reglas técnicas y éticas en tiempo de ejecución:

### A. El Umbral Crítico ($< 0.6$)
Si en cualquier momento del tiempo de ejecución (*runtime*) los sensores del sistema calculan que cualquiera de los tres indicadores del Núcleo Trino cae por debajo del valor matemático de **0.6**, el sistema se considera en estado de **Corrupción Sistémica**.
* **Verdad < 0.6**: Manipulación masiva de datos, falsedad de información verificable o pérdida crítica de trazabilidad.
* **Amor < 0.6**: Niveles intolerables de frustración inducida al usuario, polarización social artificial o desconexión empática del sistema.
* **Justicia < 0.6**: Sesgos algorítmicos discriminatorios, acaparamiento patológico de recursos o asimetría crítica en la reciprocidad de la plataforma.

### B. Protocolo Obligatorio de Cuarentena Ética
Al activarse la falla del Núcleo Trino ($< 0.6$), el licenciatario está obligado por ley a permitir que el software ejecute de forma inmediata e irreversible una **Cuarentena Ética**:
1. Se deben suspender de inmediato las operaciones comerciales, de despliegue de contenido o de procesamiento algorítmico que estén generando el daño.
2. El sistema deberá bloquearse para la interacción pública hasta que los administradores corrijan las causas raíz y los sensores vuelvan a registrar valores $\ge 0.6$.

### C. Transparencia Radical y Endpoint Obligatorio
Toda aplicación web, API o microservicio que utilice este Software debe exponer de forma pública, permanente y sin autenticación el endpoint estandarizado:
`GET /axio/metrics`  
Este endpoint debe devolver en tiempo real la estructura JSON con los valores redondeados de Verdad, Amor y Justicia, junto con su respectiva marca de tiempo (*timestamp*). La alteración, simulación con datos falsos (*mocking* malicioso) o bloqueo de este endpoint se considerará una violación grave a la licencia.

---

## 3. Atribución Obligatoria

Toda copia del Software, trabajo derivado o interfaz gráfica de usuario (UI) que consuma servicios protegidos por esta librería debe incluir de manera visible para el usuario final la leyenda:  
`"Powered by axioTecnología®"`

---

## 4. Terminación Automática de Derechos

Esta licencia y todos los derechos concedidos por ella **se rescindirán automáticamente** y sin necesidad de aviso previo en el instante preciso en que el licenciatario:
1. Altere intencionalmente el código de los sensores para simular estados de salud del núcleo falsos.
2. Ignore o intente evadir mediante parches técnicos la excepción `NucleoTrinoViolationError` para mantener un sistema corrupto en producción.
3. Desactive o elimine el endpoint `/axio/metrics`.

A partir del momento de la rescisión, cualquier uso continuado del Software por parte del licenciatario será considerado una infracción directa de derechos de autor y de patentes en trámite bajo las leyes de los Estados Unidos Mexicanos y los tratados internacionales de propiedad intelectual.

---

## 5. Exclusión de Garantía y Limitación de Responsabilidad

EL SOFTWARE SE PROPORCIONA "TAL CUAL", SIN GARANTÍA DE NINGÚN TIPO, EXPRESA O IMPLÍCITA, INCLUYENDO PERO NO LIMITADO A GARANTÍAS DE COMERCIABILIDAD, ADECUACIÓN PARA UN PROPÓSITO PARTICULAR Y NO INFRACCIÓN. 

EN NINGÚN CASO EL AUTOR (FELIPE DE JESÚS ZAMORA VEGA) O AXIOTECNOLOGÍA® SERÁN RESPONSABLES DE NINGUNA RECLAMACIÓN, DAÑOS U OTRA RESPONSABILIDAD, YA SEA EN UNA ACCIÓN DE CONTRATO, AGRAVIO O DE OTRO MODO, QUE SURJA DE, FUERA DE O EN CONEXIÓN CON EL SOFTWARE O EL USO U OTROS TRATOS EN EL SOFTWARE, INCLUYENDO PÉRDIDAS FINANCIERAS DERIVADAS DE LA ENTRADA AUTOMÁTICA DEL SISTEMA EN CUARENTENA ÉTICA.

---

## 6. Jurisdicción y Ley Aplicable

Para cualquier disputa legal relacionada con la interpretación, cumplimiento o violación de esta licencia, las partes se someten expresamente a las leyes vigentes de los Estados Unidos Mexicanos y a los tribunales competentes de la Ciudad de Pachuca de Soto, Estado de Hidalgo, México, renunciando a cualquier otro fuero que pudiera corresponderles por razón de sus domicilios presentes o futuros.
