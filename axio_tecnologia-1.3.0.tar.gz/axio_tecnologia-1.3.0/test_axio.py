import unittest
import time
import json
from flask import Flask

# Importamos los componentes del motor axio v1.3
from axio import (
    HomeostasisEngine,
    requiere_nucleo,
    exponer_protocolo_axio,
    NucleoTrinoViolationError
)

class TestAxioProtocoloDinamico(unittest.TestCase):

    def setUp(self):
        """Configuración inicial antes de cada prueba."""
        self.app = Flask(__name__)
        exponer_protocolo_axio(self.app)
        self.client = self.app.test_client()
        
        # Limpiar el historial y estados del motor antes de cada test
        HomeostasisEngine._historico_evaluaciones = []
        HomeostasisEngine._cuarentena_hasta = 0.0  # Resetear timestamp de bloqueo

        # Inyectar una simulación de cooldown de 2 segundos para las pruebas
        HomeostasisEngine.COOLDOWN_CUARENTENA = 2.0 

    def test_acumulacion_votos_clientes(self):
        """Valida que el núcleo calcule el promedio móvil correctamente."""
        # Enviamos 2 evaluaciones distintas a través del endpoint público
        self.client.post('/axio/evaluate', json={
            "calidad_informacion": 1.0, "trato_empatia": 0.8, "ausencia_sesgo": 0.9
        })
        self.client.post('/axio/evaluate', json={
            "calidad_informacion": 0.8, "trato_empatia": 0.6, "ausencia_sesgo": 0.7
        })

        # El promedio esperado de Amor debe ser (0.8 + 0.6) / 2 = 0.7
        estado = HomeostasisEngine.obtener_estado()
        self.assertAlmostEqual(estado.amor, 0.7, places=2)

    def test_bloqueo_por_threshold_de_clientes(self):
        """Valida que los votos negativos de los clientes bloqueen funciones estrictas."""
        # Los clientes evalúan negativamente la empatía (Amor)
        HomeostasisEngine.registrar_evaluacion_cliente(1.0, 0.5, 1.0)

        @requiere_nucleo(verdad=0.8, amor=0.7, justicia=0.8)
        def servicio_comercial():
            return "Completado"

        # Debe lanzar una excepción porque el Amor actual (0.5) es menor al requerido (0.7)
        with self.assertRaises(NucleoTrinoViolationError):
            servicio_comercial()

    def test_protocolo_time_slap_cuarentena(self):
        """Valida el bloqueo temporal y el restablecimiento tras el time-slap."""
        
        # 1. Provocamos una caída crítica del núcleo (< 0.6) para activar la Cuarentena
        HomeostasisEngine.registrar_evaluacion_cliente(0.9, 0.4, 0.9)
        
        # Guardamos el timestamp actual para verificar que se generó el bloqueo temporal
        timestamp_bloqueo = HomeostasisEngine._cuarentena_hasta
        self.assertTrue(timestamp_bloqueo > time.time())

        # Intentamos inyectar un voto excelente de inmediato para "engañar" al sistema
        HomeostasisEngine.registrar_evaluacion_cliente(1.0, 1.0, 1.0)

        @requiere_nucleo(verdad=0.6, amor=0.6, justicia=0.6)
        def funcion_intento_escape():
            return "Logré ejecutar"

        # A pesar del voto excelente, el sistema DEBE seguir bloqueado por el Cooldown/Time-slap
        with self.assertRaises(NucleoTrinoViolationError) as contexto:
            funcion_intento_escape()
        self.assertIn("Bajo penalización temporal", str(contexto.exception))

        # 2. Simulamos el paso del tiempo (esperamos los 2 segundos del cooldown)
        print("\n⏳ Simulando Time-slap (Esperando expiración de cuarentena)...")
        time.sleep(2.1)

        # 3. Tras el time-slap, el sistema permite evaluar de nuevo y recupera la homeostasis
        HomeostasisEngine.registrar_evaluacion_cliente(0.9, 0.9, 0.9)
        
        try:
            resultado = funcion_intento_escape()
            self.assertEqual(resultado, "Logré ejecutar")
        except NucleoTrinoViolationError:
            self.fail("El sistema no se restableció correctamente después del time-slap.")

    def test_endpoint_metrics_refleja_clientes(self):
        """Valida que /axio/metrics devuelva el estado real de la comunidad."""
        HomeostasisEngine.registrar_evaluacion_cliente(0.95, 0.85, 0.75)

        respuesta = self.client.get('/axio/metrics')
        self.assertEqual(respuesta.status_code, 200)
        
        data = json.loads(respuesta.data)
        self.assertEqual(data["nucleo_trino"]["verdad"], 0.95)
        self.assertEqual(data["nucleo_trino"]["amor"], 0.85)
        self.assertEqual(data["nucleo_trino"]["justicia"], 0.75)


# =====================================================================
# MODIFICACIONES NECESARIAS EN AXIO.PY PARA SOPORTAR ESTE TEST
# =====================================================================
# Nota: Para que este test pase, debes asegurar que tu clase HomeostasisEngine 
# en axio.py maneje el estado de la cuarentena temporal de la siguiente forma:
"""
class HomeostasisEngine:
    _estado_actual = NucleoTrino()
    _historico_evaluaciones = []
    _cuarentena_hasta = 0.0        # Timestamp hasta el cual el sistema está penalizado
    COOLDOWN_CUARENTENA = 300.0     # 5 minutos por defecto en producción
    VENTANA_MAXIMA = 50

    @classmethod
    def registrar_evaluacion_cliente(cls, verdad_voto: float, amor_voto: float, justicia_voto: float):
        # Si estamos bajo los efectos del time-slap, rechazamos recalcular positivamente
        if time.time() < cls._cuarentena_hasta:
            # Sigue penalizado, acumulamos el voto pero mantenemos el bloqueo
            pass

        cls._historico_evaluaciones.append({"verdad": verdad_voto, "amor": amor_voto, "justicia": justicia_voto})
        # ... (cálculo de promedios normales) ...
        cls._estado_actual = NucleoTrino(verdad=prom_verdad, amor=prom_amor, justicia=prom_justicia)

        # SI SE VIOLA LA LEY AXIO (< 0.6), SE ACTIVA EL TIME-SLAP
        if not cls._estado_actual.validar() and time.time() > cls._cuarentena_hasta:
            cls._cuarentena_hasta = time.time() + cls.COOLDOWN_CUARENTENA
"""

if __name__ == '__main__':
    unittest.main()
