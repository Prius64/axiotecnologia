from setuptools import setup

# Leer el README.md para que aparezca como la descripción oficial en la página web de PyPI
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="axio-tecnologia",
    version="1.3.0",  # Sincronizado con la versión del protocolo dinámico v1.3
    author="Felipe de Jesús Zamora Vega",
    author_email="fzamorazv31@gmail.com",
    description="axioTecnología® v1.3: Protocolo Criptográfico de Homeostasis Axiológica en Runtime (Verdad | Amor | Justicia)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Prius64/",  # repositorio 
    project_urls={
        "Bug Tracker": "https://github.com/issues",
        "Documentation": "https://doi.org",
        "Source Code": "https://github.com",
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "License :: Other/Proprietary License",  # Especifica que usa la axio Public License v1.1
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    # Al ser un único archivo central en la raíz, usamos py_modules
    py_modules=["axio"],
    python_requires=">=3.8",
    install_requires=[
        "Flask>=3.0.0",  # Requisito mínimo para levantar el endpoint del protocolo
    ],
    keywords="ethics, homeostasis, axiology, truth, love, justice, axio, compliance, hmac, cryptography",
)